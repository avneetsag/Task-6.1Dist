package com.example.task61d;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    EditText user, pass;
    Button login, signing;
    FirebaseAuth firebase;
    private FirebaseAuth.AuthStateListener gauth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Log In");

        firebase = FirebaseAuth.getInstance();
        user = findViewById(R.id.umail);
        pass = findViewById(R.id.upwd);
        login = findViewById(R.id.login);
        signing =findViewById(R.id.signup);


        gauth = new FirebaseAuth.AuthStateListener() {
            FirebaseUser mFirebaseUser = firebase.getCurrentUser();
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = firebase.getCurrentUser();
                if (mFirebaseUser!= null){
                    Toast.makeText(MainActivity.this, "You are logged in", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this,MainActivity2.class);
                    startActivity(i);
                }
                else {
                    Toast.makeText(MainActivity.this, "Please Login!!", Toast.LENGTH_SHORT).show();;
                }
            }
        };
        signing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intologin = new Intent(MainActivity.this, SignupActivity.class);
                startActivity(intologin);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mailid = user.getText().toString();
                String pwd = pass.getText().toString();

                if (mailid.isEmpty()){
                    user.setError("Please enter the email");
                    user.requestFocus();
                }
                else if (pwd.isEmpty()){
                    pass.setError("Please Enter user Password");
                    pass.requestFocus();
                }
                else if (mailid.isEmpty() && pwd.isEmpty()){
                    Toast.makeText(MainActivity.this, "Fields are Empty!!",Toast.LENGTH_SHORT).show();
                }
                else if (!(mailid.isEmpty() && pwd.isEmpty())){
                    firebase.signInWithEmailAndPassword(mailid,pwd).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                Toast.makeText(MainActivity.this, "Login Error, Please Login Again!!!",Toast.LENGTH_SHORT).show();
                            }
                            else{

                                Intent intoHome = new Intent(MainActivity.this, MainActivity2.class);
                                startActivity(intoHome);
                            }
                        }
                    });
                }
                else {
                    Toast.makeText(MainActivity.this, "Error Occurred!!", Toast.LENGTH_SHORT).show();;
                }
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        firebase.addAuthStateListener(gauth);
    }




}
